@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ABOUT MY EDUCATION</h1>

              <div class="panel panel-default">
              	<H3>
  				Elementary : Mandaue City Central School <BR><BR>
  				High School : University of Visayas Mandaue Branch<BR><BR>
  				College : University Of Cebu – Main Campus (Present) <BR>
  				Course : Bachelor of Science in Information Technology<BR><BR>
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
@stop