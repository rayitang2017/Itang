@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>

              <div class="panel panel-default">
              	<H5>
  				  My name is Raymart E. Itang.<BR><BR>
  				  I am currently living in Upper ranudo St ramos, Cebu.<BR><BR>
  				  I am the eldest and i have a little brother who is just 1 year gap to me.<BR><BR>
  				  I was born in Mandaue, Cebu.<BR><BR>
  				  I am a student in University of Cebu Main Campus.<BR><BR>
  				  I have work in Robina Corporation for 4 months and in Gaisano Capital for 1 year and 2 weeks.<BR><BR>
  				  My hobbies ang drawing and designing but most of all is eating.<BR><BR>
  				  Hopefully i can finished this coming march so i can work and help my family espicially my 
            father.<BR><BR>
  				  and i would like to continue my passion of game development and character design,<BR><BR>
  				  and so I am here, trying to finished what i started and hopefully can become one someday,<BR><BR>
  				  I will continue to work hard and study.<BR><BR>
  				  Hopefully I will be able to finish my dept this year.<BR><BR>
  				  As a professional in terms of work, I can proudly say that<BR><BR>
  				  I am able to work with speed, accuracy and can work under high pressure.<BR><BR>
  				  I am highly dedicated and persevering with a positive attitude.<BR><BR>
  				  I am trainable and able to work with less supervision.<BR><BR>
  				  I also have a flexible personality, maturity and brave<BR><BR>
  				  I am able to work independently or as a part of a team but mostly if i can do it alone i will do it alone.<BR><BR>
  				  Because of these reasons that I am confident that I can have a bright future ahead of me and<BR><BR>
  				  I am looking forward to the mysterious future ahead of me.
              </H5>
              </div>
            </div>
        </div>
    </div>
</div>

@stop